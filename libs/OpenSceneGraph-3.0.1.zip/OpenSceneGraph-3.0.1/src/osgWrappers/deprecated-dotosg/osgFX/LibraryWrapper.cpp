#include <osgDB/Registry>

USE_DOTOSGWRAPPER(AnisotropicLighting_Proxy)
USE_DOTOSGWRAPPER(BumpMapping_Proxy)
USE_DOTOSGWRAPPER(Cartoon_Proxy)
USE_DOTOSGWRAPPER(Effect_Proxy)
USE_DOTOSGWRAPPER(MultiTextureControl_Proxy)
USE_DOTOSGWRAPPER(Outline_Proxy)
USE_DOTOSGWRAPPER(Scribe_Proxy)
USE_DOTOSGWRAPPER(SpecularHighlights_Proxy)

extern "C" void dotosgwrapper_library_osgFX(void) {}

