#include <osgDB/Registry>

USE_DOTOSGWRAPPER(CompositeLayer_Proxy)
USE_DOTOSGWRAPPER(GeometryTechnique_Proxy)
USE_DOTOSGWRAPPER(HeightFieldLayer_Proxy)
USE_DOTOSGWRAPPER(ImageLayer_Proxy)
USE_DOTOSGWRAPPER(Layer_Proxy)
USE_DOTOSGWRAPPER(Locator_Proxy)
USE_DOTOSGWRAPPER(SwitchLayer_Proxy)
USE_DOTOSGWRAPPER(Terrain)
USE_DOTOSGWRAPPER(TerrainTile_Proxy)

extern "C" void dotosgwrapper_library_osgTerrain(void) {}

