#include <osgDB/Registry>

USE_DOTOSGWRAPPER(ShadowedScene_Proxy)
USE_DOTOSGWRAPPER(ShadowMap_Proxy)
USE_DOTOSGWRAPPER(ShadowTechnique_Proxy)
USE_DOTOSGWRAPPER(ShadowTexture_Proxy)
USE_DOTOSGWRAPPER(ShadowVolume_Proxy)

extern "C" void dotosgwrapper_library_osgShadow(void) {}

